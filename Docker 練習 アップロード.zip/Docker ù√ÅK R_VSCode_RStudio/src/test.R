setwd("/workspace")
getwd()
packageVersion("dplyr")

# Write "testmessage" to a text file
writeLines("testmessage", "data/testmessage.txt")